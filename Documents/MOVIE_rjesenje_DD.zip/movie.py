# TODO:
# Potrebno je implementirati konstruktor za razred Movie.
# Konstruktor prima dva argumenta, ime filma i godinu.
# Razred sadrzi dvije varijable instance (atribute): ime filma i godinu.
# Razred `Movie` morate iskoristiti u drugim podzadacima u ovom projektu.
class Movie:
    def __init__(self, name, year):
        self.name = name
        self.year = year
    pass
